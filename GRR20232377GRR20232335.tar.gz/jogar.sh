#!/bin/bash

# Limpa o terminal
clear

# Verifica se o argumento foi passado
if [ -z "$1" ]; then
    echo "Uso: ./script.sh <1 a 4>"
    exit 1
fi

x=$1

# Checa o valor de x
case $x in
    1)
        echo "Executando comandos para o jogador 1"
        ./exec 10.254.224.56 10.254.224.52 1 
        ;;
    2)
        echo "Executando comandos para o jogador 2"
        ./exec 10.254.224.52 10.254.224.57 2  
        ;;
    3)
        echo "Executando comandos para o jogador 3"
        ./exec 10.254.224.57 10.254.224.55 3  
        ;;
    4)
        echo "Executando comandos para o jogador 4"
    	if gcc -O0 -g maquinas.c -o exec; then
        	./exec 10.254.224.55 10.254.224.56 4  
    	else
        	echo "Erro: Falha na compilação. Corrija os erros no código."
    	fi
        ;;
    *)
        echo "Número inválido. Use um número de 1 a 4."
        exit 1
        ;;
esac

